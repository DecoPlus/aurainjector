AURA INJECTOR 1.3
1–10 ZIP files, independent source and destination rules

QUICK START

1. Extract this package into a new folder. Run START_Aura_Injector.bat.
2. Set Game folder to the folder containing the game's .exe. You can also
   choose an installed game from Steam games. Manual selection works too.
3. The app starts with one ZIP card. Use Add ZIP to add up to ten cards.
   Use Remove on a card to remove it. The last card cannot be removed.
4. Choose a ZIP on every active card. ZIP folder lists available archives;
   each card's Browse button can also select a ZIP from a different folder.
5. Set Copy, Inside ZIP (when applicable), and Copy to for EACH ZIP.
6. Set Data folder only if a destination uses Data folder or Data folder / Lang.
7. Click Check files. File preview shows every source and exact destination,
   followed by the individual source -> destination files.
8. Close the game, click Inject, and confirm.

PACKAGE COUNT AND DEFAULTS

One ZIP is enough. Ten is the maximum. Every active card needs a different
ZIP file; remove unused cards. The counter shows the active count.
New cards use Full archive -> Game root. No position forces a particular
mode or destination. Reset copy rules resets every active card to these
settings, keeping its selected ZIP and the number of cards.

Removing a card keeps all other cards' settings and their relative order.
The remaining cards are renumbered. Adding/removing cards or editing any
copy setting invalidates the preview; run Check files again before Inject.
Package controls are locked while checking, installing or restoring.

COPY MODES

Full archive:
  Copy every file and folder while preserving paths inside the ZIP.
Folder contents:
  Select a folder from Inside ZIP. Only that folder's CONTENTS are copied.
  Its name and parent folders are stripped. Its own subfolders are kept.
  Files outside the selected folder are excluded. Nested folders can be
  selected too, including folders inferred from ZIP file paths.

With a single outer folder, Folder contents can select that folder for you.
With multiple folders or loose root files, choose the source explicitly.

DESTINATIONS — AVAILABLE IN EVERY CARD

Game root:          The selected Game folder itself.
Data folder:        Game folder / the selected Data folder.
Data folder / Lang: Game folder / the selected Data folder / Lang.
Custom subfolder:   Any relative path inside the game folder.

For Custom subfolder, enter a path such as Mods/MyPlugin or
Game_Data/StreamingAssets/Translations. Missing folders are created.
Browse can select an existing folder. To use the root, choose Game root.

The Data folder setting accepts an existing direct child of Game folder.
A single *_Data folder is selected automatically; other names can be chosen.
For deeper paths use Custom subfolder. No Data folder is required when all
packages use Game root or Custom subfolder. The app can copy files for
Windows games made with other engines as well as Unity.

EXAMPLE: YOUR ORIGINAL THREE-PACKAGE SETUP

Add two ZIP cards, so there are three, then choose:
ZIP 1: Full archive    -> Game root
ZIP 2: Folder contents -> Game root
ZIP 3: Folder contents -> Data folder

ZIP 1 entry: BepInEx/plugins/Mod.dll
Result:      Game/BepInEx/plugins/Mod.dll
ZIP 2 entry: Release/config/settings.ini; Inside ZIP = Release
Result:      Game/config/settings.ini
ZIP 3 entry: TranslationPack/hu.json; Inside ZIP = TranslationPack
Data folder: MyGame_Data
Result:      Game/MyGame_Data/hu.json

Lang is only appended if Copy to = Data folder / Lang is explicitly chosen.
These rules are examples; any of the 1–10 ZIPs can use any copy rule.

PREVIEW AND CONFLICTS

Packages are processed from top to bottom. At an identical destination,
the later ZIP wins. Folders are merged; a file replacement replaces the
whole file, not individual lines. The preview shows final files after
conflicts, original ZIP paths, and whether replacement/backup is needed.
Package counts show selected files before cross-package conflicts.
Unrelated files remain untouched. ZIPs are not executed or deleted.
__MACOSX and .DS_Store metadata files are ignored.

Both the package list and the preview can scroll. Injection controls and
the progress bar stay visible outside the scrolling package list.

ANIMATED INJECTION

Animated injection adds smooth progress and four short, cancellable pauses,
roughly 2–3 seconds in total. Turn it off for immediate, unpaced progress.
The app remains responsive. Success is shown only after files have actually
been installed. The animation does not imply extra validation.

BACKUP, RESTORE AND UPGRADES

Backups use Game folder/.tp-injector-backups. This folder and the operation
lock retain their old names so Aura Injector and TP Injector 1.0–1.2 share
one backup history and cannot run competing operations on the same game.
The interface, launcher, source files and newly built EXE use the Aura name.

Dated backup folders contain original/ (replaced files), new/ (staged files)
and manifest.json (destinations and operation state). Keep them if you may
need to restore. Restore last injection uses saved paths, not current ZIP
settings: only Game folder needs to be selected.

Restore replaces original files and removes files added by that injection.
Only empty directories created by the operation are removed. Backups are
kept. Restore multiple injections newest first. If an affected file was
edited later, restore stops to protect it. Save those edits separately,
restore the installed copy from the backup's new/ folder, then retry if you
want to undo that injection.

Handled failures and cancellation roll back applied changes. If a locked or
inaccessible file also prevents rollback, keep the backup and resolve that
error before retrying Restore. After power loss or forced exit, ensure no
Aura or TP Injector is running, remove .tp-injector.lock from the game folder,
then use Restore last injection. Unfinished injections block new installs.

To correct an older injection's destination, restore it first, then inject
using your corrected rules. TP 1.0, 1.1 and 1.2 backups remain restorable.
If you previously built an EXE, build again; the new launcher uses only
Aura_Injector_1.3.exe, so it cannot accidentally run an older TP executable.

REQUIREMENTS AND EXE BUILD

Source version: Windows + Python 3.10 or newer with tkinter.
No pip packages are required to run it.
Python: https://www.python.org/downloads/windows/
Enable Add Python to PATH and Tcl/Tk and IDLE in the installer.

This package contains source code and launch/build scripts, not a prebuilt
Windows executable. Run BUILD_EXE.bat on Windows to build Aura_Injector_1.3.exe.
PyInstaller is downloaded into .aura-build-venv for the build. The resulting
EXE runs without Python and can be shared with your ZIP files.

TROUBLESHOOTING

No Steam game found: browse to the game's .exe folder manually.
No ZIPs in the dropdown: choose ZIP folder and click Refresh, or use Browse.
The ZIP folder listing is not recursive; Browse can select a ZIP anywhere.
No source folders: choose a valid ZIP and wait for the folder list to load.
No data folder selected: choose it above, or use a different destination.
Access denied: close the game and tools using its files. If the game folder
requires administrator rights, run the launcher with those rights.
Error details go to aura-injector-error.log beside the program if writable.

Encrypted ZIPs, symbolic links and junctions are unsupported. Limits are
100,000 total ZIP entries and 32 GiB expanded data across all packages.
The preview lists up to 5,000 final files; injection covers the whole plan.
The tool copies files. In-game translation/mod compatibility depends on the
selected files and the game's version; see ELLENORZES.txt for test scope.

FILES

aura_injector.py          English interface and dynamic ZIP list
aura_core.py              ZIP analysis, copy rules, backup, restore, Steam lookup
aura_progress.py          Optional progress effects
START_Aura_Injector.bat   Launcher
BUILD_EXE.bat            Windows EXE builder
README.txt               English guide
HASZNALAT.txt            Hungarian guide
ELLENORZES.txt           Verification scope and limits
tests/                   Automated file-operation and UI logic tests
