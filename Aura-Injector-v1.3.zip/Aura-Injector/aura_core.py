"""Aura Injector: 1–10 ZIPs -> one game folder. Standard library only."""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import threading
import uuid
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

# Keep the existing on-disk names to share backups and the operation lock
# with earlier TP Injector versions. New manifests use the Aura brand.
BACKUPS = ".tp-injector-backups"
LOCK = ".tp-injector.lock"
MIN_PACKAGES = 1
MAX_PACKAGES = 10
MAX_FILES = 100_000
MAX_BYTES = 32 * 1024**3
CHUNK = 1024 * 1024
Progress = Callable[[str, int, int], None]


class InjectorError(Exception):
    pass


class Cancelled(InjectorError):
    pass


@dataclass(frozen=True)
class Entry:
    archive: Path
    index: int
    member: str
    relative: str
    size: int
    crc: int


@dataclass
class Plan:
    target: Path
    archives: tuple[Path, ...]
    signatures: tuple[tuple[int, int], ...]
    files: list[Entry]
    directories: list[str]
    rules: tuple[PackageRule, ...]
    collisions: list[str]
    overwrite: list[str]
    package_counts: tuple[int, ...]

    @property
    def size(self):
        return sum(e.size for e in self.files)


@dataclass(frozen=True)
class PackageRule:
    mode: str = "full"  # full archive, or the CONTENTS of source_folder
    source_folder: str = ""  # empty in folder mode = auto only when unambiguous
    destination: str = ""  # path relative to game root; empty = root


@dataclass(frozen=True)
class ZipContents:
    folders: tuple[str, ...]
    suggested_folder: str
    file_count: int


def _check_cancel(cancel):
    if cancel is not None and cancel.is_set():
        raise Cancelled("Operation cancelled.")


def _linked(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & 0x400
    )


def _parts(name: str) -> tuple[str, ...]:
    name = name.replace("\\", "/")
    if name.startswith("/") or "\x00" in name:
        raise InjectorError(f"Unsafe path: {name!r}")
    parts = tuple(name.rstrip("/").split("/"))
    for part in parts:
        if not part or part in (".", "..") or part[-1:] in (" ", "."):
            raise InjectorError(f"Invalid path: {name!r}")
        if any(ord(c) < 32 or c in '<>:"|?*' for c in part):
            raise InjectorError(f"Invalid Windows filename: {name!r}")
        stem = part.split(".")[0].upper()
        if stem in {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"} or re.fullmatch(
            r"(?:COM|LPT)[1-9¹²³]", stem
        ):
            raise InjectorError(f"Reserved Windows filename: {name!r}")
    if parts[0].casefold() in {BACKUPS.casefold(), LOCK.casefold()}:
        raise InjectorError("The ZIP would overwrite the Injector backup area.")
    return parts


def _safe_child(root: Path, relative: str) -> Path:
    parts = _parts(relative)
    current = root
    if _linked(root):
        raise InjectorError(f"Cannot copy into a link: {root}")
    for part in parts:
        current = current / part
        if _linked(current):
            raise InjectorError(f"Cannot copy into a link or junction: {current}")
    return current


def validate_target(target) -> Path:
    root = Path(target).expanduser().resolve(strict=True)
    if not root.is_dir() or root == Path(root.anchor):
        raise InjectorError("Select the game folder.")
    if root.name.casefold() in {"steamapps", "common"} or (root / "steam.exe").exists():
        raise InjectorError("Select the game folder, not the Steam or common root folder.")
    if not any(p.is_file() and p.suffix.casefold() == ".exe" for p in root.iterdir()):
        raise InjectorError("Select the folder containing the game executable (.exe).")
    for name in (BACKUPS, LOCK):
        if _linked(root / name):
            raise InjectorError(f"The backup location is a link: {root / name}")
    return root


def _signature(path):
    info = path.stat()
    return info.st_size, info.st_mtime_ns


def discover_data_folders(target) -> list[str]:
    """Direct child folders only; Unity *_Data folders are shown first."""
    root = Path(target).expanduser()
    if not root.is_dir():
        return []
    names = []
    for child in root.iterdir():
        if child.is_dir() and not _linked(child):
            try:
                _parts(child.name)
                names.append(child.name)
            except InjectorError:
                continue
    return sorted(names, key=lambda n: (not n.casefold().endswith("_data"), n.casefold()))


def resolve_data_folder(root: Path, selection: str | None = None) -> str:
    if not selection:
        candidates = [name for name in discover_data_folders(root) if name.casefold().endswith("_data")]
        if len(candidates) != 1:
            raise InjectorError("Select the game's data folder, or choose another destination for each ZIP.")
        selection = candidates[0]
    if len(_parts(selection)) != 1:
        raise InjectorError("The data folder must be directly inside the game folder.")
    selected = _safe_child(root, selection)
    if not selected.is_dir():
        raise InjectorError(f"Data folder not found: {selection}")
    return selected.name


def _read_archive(path, cancel=None):
    """Validate archive metadata once. No files are extracted here."""
    entries = []
    size = 0
    with zipfile.ZipFile(path) as zf:
        for index, info in enumerate(zf.infolist()):
            _check_cancel(cancel)
            parts = _parts(info.orig_filename)
            if parts[0] == "__MACOSX" or parts[-1] == ".DS_Store":
                continue
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode) or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise InjectorError(f"The ZIP contains a special file: {info.filename}")
            if info.flag_bits & 1:
                raise InjectorError(f"Password-protected ZIP files are not supported: {Path(path).name}")
            directory = info.is_dir() or info.filename.endswith("\\")
            if directory and info.file_size:
                raise InjectorError(f"Invalid directory entry: {info.filename}")
            entries.append((index, info, parts, directory))
            size += info.file_size
            if len(entries) > MAX_FILES or size > MAX_BYTES:
                raise InjectorError("Package too large: the limits are 100,000 entries and 32 GiB.")
    return entries


def _archive_contents(entries):
    folders = set()
    for _, _, parts, directory in entries:
        for depth in range(1, len(parts) + (1 if directory else 0)):
            folders.add("/".join(parts[:depth]))
    roots = {e[2][0] for e in entries}
    suggested = ""
    if len(roots) == 1 and all(e[3] or len(e[2]) > 1 for e in entries):
        suggested = next(iter(roots))
    return ZipContents(tuple(sorted(folders, key=str.casefold)), suggested,
                       sum(not e[3] for e in entries))


def inspect_archive(path, cancel=None) -> ZipContents:
    return _archive_contents(_read_archive(Path(path), cancel))


def make_plan(archives, target, cancel=None, *, rules=None) -> Plan:
    root = validate_target(target)
    archives = tuple(archives)
    if not MIN_PACKAGES <= len(archives) <= MAX_PACKAGES:
        raise InjectorError(f"Select between {MIN_PACKAGES} and {MAX_PACKAGES} ZIP files.")
    rules = tuple(rules) if rules is not None else (PackageRule(),) * len(archives)
    if len(rules) != len(archives) or any(not isinstance(rule, PackageRule) for rule in rules):
        raise InjectorError("Specify one copy rule for each selected ZIP file.")
    paths = tuple(Path(p).expanduser().resolve(strict=True) for p in archives)
    if len({str(p).casefold() for p in paths}) != len(paths):
        raise InjectorError("Choose a different ZIP file for each package.")
    signatures = tuple(_signature(p) for p in paths)
    files: dict[str, Entry] = {}
    directories: dict[str, str] = {}
    spelling: dict[str, str] = {}
    collisions = []
    resolved_rules = []
    package_counts = []
    byte_count = 0
    entry_count = 0

    def canonical(parts):
        result = []
        for part in parts:
            key = "/".join(result + [part]).casefold()
            result.append(spelling.setdefault(key, part))
        return "/".join(result)

    for position, archive in enumerate(paths):
        _check_cancel(cancel)
        if archive.suffix.lower() != ".zip":
            raise InjectorError(f"Not a ZIP file: {archive.name}")
        entries = _read_archive(archive, cancel)
        contents = _archive_contents(entries)
        if not contents.file_count:
            raise InjectorError(f"No installable files found in this ZIP: {archive.name}")
        rule = rules[position]
        if rule.mode not in {"full", "folder"}:
            raise InjectorError(f"ZIP {position + 1}: unknown copy mode.")
        if rule.mode == "full" and rule.source_folder:
            raise InjectorError(f"ZIP {position + 1}: full archive mode cannot specify an inner folder.")
        source = ()
        if rule.mode == "folder":
            folder = rule.source_folder or contents.suggested_folder
            if not folder:
                raise InjectorError(f"ZIP {position + 1}: choose the folder inside the ZIP whose contents you want to copy.")
            source = _parts(folder)
            if "/".join(source) not in contents.folders:
                raise InjectorError(f"ZIP {position + 1}: folder not found in archive: {folder}")
        destination = _parts(rule.destination) if rule.destination not in {"", "."} else ()
        resolved_rules.append(PackageRule(rule.mode, "/".join(source), "/".join(destination)))
        selected_files = 0
        for index, info, parts, directory in entries:
            _check_cancel(cancel)
            entry_count += 1
            byte_count += info.file_size
            if entry_count > MAX_FILES or byte_count > MAX_BYTES:
                raise InjectorError("Package too large: the limits are 100,000 entries and 32 GiB.")
            if source:
                if parts[:len(source)] != source:
                    continue
                parts = parts[len(source):]
            if not parts:
                continue
            _parts("/".join(parts))
            parts = destination + parts
            relative = canonical(parts)
            _parts(relative)
            for depth in range(1, len(parts) + (1 if directory else 0)):
                parent = "/".join(relative.split("/")[:depth])
                directories[parent.casefold()] = parent
            if not directory:
                selected_files += 1
                key = relative.casefold()
                if key in files:
                    collisions.append(relative)
                files[key] = Entry(archive, index, info.filename, relative, info.file_size, info.CRC)
        if not selected_files:
            raise InjectorError(f"ZIP {position + 1}: the selected source folder contains no files.")
        package_counts.append(selected_files)
    for key in files:
        if key in directories:
            raise InjectorError(f"The same path would be both a file and a folder: {files[key].relative}")
    for relative in directories.values():
        dest = _safe_child(root, relative)
        if dest.exists() and not dest.is_dir():
            raise InjectorError(f"A file is blocking a required folder: {relative}")
    overwrite = []
    for entry in files.values():
        dest = _safe_child(root, entry.relative)
        if dest.exists():
            if not dest.is_file():
                raise InjectorError(f"A folder is blocking a required file: {entry.relative}")
            overwrite.append(entry.relative)
    if signatures != tuple(_signature(p) for p in paths):
        raise InjectorError("A ZIP changed during inspection. Run Check files again.")
    return Plan(root, paths, signatures, list(files.values()),
                sorted(directories.values(), key=lambda p: (p.count("/"), p.casefold())),
                tuple(resolved_rules), sorted(set(collisions)), overwrite, tuple(package_counts))


def digest(path: Path, cancel=None) -> str:
    result = hashlib.sha256()
    with path.open("rb") as source:
        while True:
            _check_cancel(cancel)
            chunk = source.read(CHUNK)
            if not chunk:
                break
            result.update(chunk)
    return result.hexdigest()


def _save_manifest(backup, data):
    temp = backup / "manifest.tmp"
    with temp.open("w", encoding="utf-8") as output:
        json.dump(data, output, ensure_ascii=False, indent=2)
        output.flush()
        os.fsync(output.fileno())
    os.replace(temp, backup / "manifest.json")


@contextlib.contextmanager
def _lock(root):
    path = root / LOCK
    try:
        handle = path.open("x", encoding="utf-8")
    except FileExistsError:
        raise InjectorError(
            "Another Aura Injector operation is running, or a previous operation was interrupted. "
            "Close all other instances. If none are running, delete "
            "the .tp-injector.lock file from the game folder, then use Restore last injection."
        ) from None
    try:
        handle.write(str(os.getpid()))
        handle.close()
        yield
    finally:
        handle.close()
        path.unlink(missing_ok=True)


def _atomic_copy(source: Path, destination: Path):
    fd, name = tempfile.mkstemp(prefix=".tp-", suffix=".tmp", dir=destination.parent)
    os.close(fd)
    temp = Path(name)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def _remove_empty(root, directories):
    for relative in sorted(directories, key=lambda p: p.count("/"), reverse=True):
        try:
            _safe_child(root, relative).rmdir()
        except OSError:
            pass


def install(plan: Plan, progress: Progress = lambda *_: None, cancel=None) -> Path:
    root = validate_target(plan.target)
    with _lock(root):
        current = make_plan(plan.archives, root, cancel, rules=plan.rules)
        if current != plan:
            raise InjectorError("The ZIPs or the game folder have changed. Run Check files again.")
        parent = root / BACKUPS
        if parent.exists() and any(
            _read_state(p) in {"applying", "restoring", "recovery_needed"}
            for p in parent.iterdir() if p.is_dir()
        ):
            raise InjectorError("An interrupted injection was found. Use Restore last injection first.")
        # Staged files remain in the backup while copies are installed into the game.
        need = 2 * plan.size + sum(_safe_child(root, p).stat().st_size for p in plan.overwrite)
        need += max((e.size for e in plan.files), default=0) + 16 * 1024**2
        if shutil.disk_usage(root).free < need:
            raise InjectorError("Not enough free disk space for extraction and backup.")
        parent.mkdir(exist_ok=True)
        backup = parent / (datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-" + uuid.uuid4().hex[:6])
        backup.mkdir()
        staged = backup / "new"
        original = backup / "original"
        staged.mkdir()
        original.mkdir()
        data = {"schema": 1, "target": str(root), "status": "preparing",
                "injector_name": "Aura Injector", "injector_version": "1.3",
                "rules": [asdict(rule) for rule in plan.rules],
                "created": datetime.now().isoformat(), "archives": [str(p) for p in plan.archives],
                "files": [], "created_dirs": []}
        _save_manifest(backup, data)
        applied = []
        try:
            total = max(1, plan.size)
            done = 0
            with contextlib.ExitStack() as stack:
                opened = {path: stack.enter_context(zipfile.ZipFile(path)) for path in plan.archives}
                infos = {path: archive.infolist() for path, archive in opened.items()}
                for entry in plan.files:
                    _check_cancel(cancel)
                    temp = _safe_child(staged, entry.relative)
                    temp.parent.mkdir(parents=True, exist_ok=True)
                    info = infos[entry.archive][entry.index]
                    if (info.filename, info.file_size, info.CRC) != (entry.member, entry.size, entry.crc):
                        raise InjectorError("A ZIP has changed since inspection.")
                    sha = hashlib.sha256()
                    amount = 0
                    with opened[entry.archive].open(info) as source, temp.open("xb") as output:
                        while True:
                            _check_cancel(cancel)
                            chunk = source.read(CHUNK)
                            if not chunk:
                                break
                            amount += len(chunk)
                            if amount > entry.size:
                                raise InjectorError(f"Invalid ZIP entry size: {entry.member}")
                            output.write(chunk)
                            sha.update(chunk)
                            done += len(chunk)
                            progress("Extracting: " + entry.relative, int(60 * done / total), 100)
                    if amount != entry.size:
                        raise InjectorError(f"Incomplete ZIP entry: {entry.member}")
                    destination = _safe_child(root, entry.relative)
                    existed = destination.exists()
                    before = None
                    if existed:
                        old = _safe_child(original, entry.relative)
                        old.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(destination, old)
                        before = digest(old, cancel)
                        if digest(destination, cancel) != before:
                            raise InjectorError(f"File changed during backup: {entry.relative}")
                    data["files"].append({"path": entry.relative, "existed": existed,
                                          "before": before, "after": sha.hexdigest()})
            if plan.signatures != tuple(_signature(p) for p in plan.archives):
                raise InjectorError("A ZIP changed during extraction.")
            _check_cancel(cancel)
            data["created_dirs"] = [p for p in plan.directories if not _safe_child(root, p).exists()]
            data["status"] = "applying"
            _save_manifest(backup, data)
            for relative in plan.directories:
                _safe_child(root, relative).mkdir(exist_ok=True)
            for index, record in enumerate(data["files"]):
                _check_cancel(cancel)
                destination = _safe_child(root, record["path"])
                actual = digest(destination, cancel) if destination.is_file() else None
                if actual != record["before"] or destination.exists() != record["existed"]:
                    raise InjectorError(f"The destination file changed during injection: {record['path']}")
                _atomic_copy(_safe_child(staged, record["path"]), destination)
                applied.append(record)
                progress("Injecting: " + record["path"], 60 + int(39 * (index + 1) / len(data["files"])), 100)
            data["status"] = "installed"
            _save_manifest(backup, data)
        except BaseException as exc:
            failures = []
            for record in reversed(applied):
                try:
                    destination = _safe_child(root, record["path"])
                    if record["existed"]:
                        _atomic_copy(_safe_child(original, record["path"]), destination)
                    else:
                        destination.unlink(missing_ok=True)
                except Exception as rollback_error:
                    failures.append(str(rollback_error))
            _remove_empty(root, data["created_dirs"])
            data["status"] = "recovery_needed" if failures else "rolled_back"
            data["error"] = str(exc)
            _save_manifest(backup, data)
            if failures:
                raise InjectorError(f"Injection failed and automatic rollback could not finish. "
                                    f"Keep this backup: {backup}\n" + "\n".join(failures)) from exc
            raise
        progress("Injection complete.", 100, 100)
        return backup


def _read_state(backup):
    try:
        return json.loads((backup / "manifest.json").read_text(encoding="utf-8")).get("status")
    except (OSError, ValueError, AttributeError):
        return None


def latest_backup(target) -> Path | None:
    root = validate_target(target)
    parent = root / BACKUPS
    if not parent.is_dir():
        return None
    for backup in sorted(parent.iterdir(), reverse=True):
        if not _linked(backup) and backup.is_dir() and _read_state(backup) in {
            "installed", "applying", "restoring", "recovery_needed"
        }:
            return backup
    return None


def restore(target, backup: Path, progress: Progress = lambda *_: None):
    root = validate_target(target)
    backup = Path(backup).absolute()
    if backup.parent != root / BACKUPS or _linked(backup):
        raise InjectorError("This backup does not belong to the selected game folder.")
    with _lock(root):
        if latest_backup(root) != backup:
            raise InjectorError("Restore the most recent injection first.")
        data = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))
        if data.get("schema") != 1 or data.get("target") != str(root):
            raise InjectorError("The backup belongs to another game or is invalid.")
        records = data["files"]
        for index, record in enumerate(records):
            destination = _safe_child(root, record["path"])
            if destination.exists() and not destination.is_file():
                raise InjectorError(f"The destination type has changed: {record['path']}")
            current = digest(destination) if destination.is_file() else None
            if current not in {record["after"], record["before"]}:
                raise InjectorError(
                    f"File modified after injection: {record['path']}\n"
                    "Restore stopped to protect this later modification."
                )
            if record["existed"]:
                source = _safe_child(backup / "original", record["path"])
                if not source.is_file() or digest(source) != record["before"]:
                    raise InjectorError(f"Missing or damaged original backup: {record['path']}")
            progress("Checking backup: " + record["path"], int(45 * (index + 1) / len(records)), 100)
        for relative in data["created_dirs"]:
            _safe_child(root, relative)
        data["status"] = "restoring"
        _save_manifest(backup, data)
        for index, record in enumerate(reversed(records)):
            destination = _safe_child(root, record["path"])
            current = digest(destination) if destination.is_file() else None
            if current not in {record["before"], record["after"]}:
                raise InjectorError(f"File changed during restore: {record['path']}")
            if current != record["before"]:
                if record["existed"]:
                    _atomic_copy(_safe_child(backup / "original", record["path"]), destination)
                else:
                    destination.unlink(missing_ok=True)
            progress("Restoring: " + record["path"], 45 + int(54 * (index + 1) / len(records)), 100)
        _remove_empty(root, data["created_dirs"])
        data["status"] = "restored"
        _save_manifest(backup, data)
        progress("Restore complete.", 100, 100)


def discover_steam_games() -> list[tuple[str, str]]:
    """Local files/registry only; manual folder selection is always available."""
    roots = set()
    if os.name == "nt":
        import winreg
        for hive, key, value in [
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
        ]:
            try:
                with winreg.OpenKey(hive, key) as handle:
                    roots.add(Path(winreg.QueryValueEx(handle, value)[0]))
            except OSError:
                pass
        for variable in ("ProgramFiles(x86)", "ProgramFiles"):
            if os.environ.get(variable):
                roots.add(Path(os.environ[variable]) / "Steam")
    roots.update({Path.home() / ".steam/steam", Path.home() / ".local/share/Steam"})
    libraries = set(roots)
    for root in roots:
        for config in [root / "steamapps/libraryfolders.vdf", root / "config/libraryfolders.vdf"]:
            try:
                text = config.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for value in re.findall(r'"(?:path|\d+)"\s*"([^"\r\n]+)"', text):
                path = Path(value.replace("\\\\", "\\"))
                if path.is_absolute() and (path / "steamapps").is_dir():
                    libraries.add(path)
    games = {}
    for library in libraries:
        for manifest in (library / "steamapps").glob("appmanifest_*.acf"):
            try:
                text = manifest.read_text(encoding="utf-8", errors="replace")
                name = re.search(r'"name"\s*"([^"\r\n]+)"', text)
                directory = re.search(r'"installdir"\s*"([^"\r\n]+)"', text)
                if not name or not directory:
                    continue
                parts = _parts(directory.group(1))
                folder = library / "steamapps/common"
                folder = folder.joinpath(*parts)
                if folder.is_dir():
                    games[str(folder.resolve()).casefold()] = (name.group(1), str(folder.resolve()))
            except (OSError, InjectorError):
                continue
    return sorted(games.values(), key=lambda item: (item[0].casefold(), item[1]))
