"""Aura Injector 1.3: 1–10 ZIPs with independent copy rules."""
from __future__ import annotations

import os
import queue
import sys
import threading
import time
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from aura_core import (MIN_PACKAGES, MAX_PACKAGES, Cancelled, InjectorError, PackageRule, discover_data_folders,
                     discover_steam_games, inspect_archive, install, latest_backup,
                     make_plan, resolve_data_folder, restore, validate_target)
from aura_progress import AnimatedProgress, smooth_step

BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
BG, CARD, TEXT, MUTED, ACCENT = "#0d1118", "#171e28", "#edf2f7", "#99a9bd", "#70ecc9"
MODES = ("Full archive", "Folder contents")
DESTINATIONS = ("Game root", "Data folder", "Data folder / Lang", "Custom subfolder")


def size_text(amount):
    for unit in ("B", "KiB", "MiB", "GiB"):
        if amount < 1024 or unit == "GiB":
            return f"{amount:.1f} {unit}"
        amount /= 1024


class PackageCard(ttk.LabelFrame):
    def __init__(self, parent, app, index):
        super().__init__(parent, text=f"ZIP {index + 1}", padding=(12, 7))
        self.app, self.index = app, index
        self.archive = tk.StringVar()
        self.mode = tk.StringVar(value=MODES[0])
        self.folder = tk.StringVar()
        self.destination = tk.StringVar(value=DESTINATIONS[0])
        self.custom = tk.StringVar()
        self.hint = tk.StringVar(value="Choose a ZIP file.")
        self.contents = None
        self.scan_generation = 0
        self.scan_timer = None
        self.columnconfigure(1, weight=1)
        self.columnconfigure(3, weight=2)
        ttk.Label(self, text="ZIP file", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.zip_box = ttk.Combobox(self, textvariable=self.archive)
        self.zip_box.grid(row=0, column=1, columnspan=3, sticky="ew", pady=3)
        self.zip_button = ttk.Button(self, text="Browse", command=self.browse_zip)
        self.zip_button.grid(row=0, column=4, padx=(8, 0))
        ttk.Label(self, text="Copy", style="Card.TLabel").grid(row=1, column=0, sticky="w")
        self.mode_box = ttk.Combobox(self, textvariable=self.mode, values=MODES, state="readonly", width=19)
        self.mode_box.grid(row=1, column=1, sticky="ew", pady=3)
        ttk.Label(self, text="Inside ZIP", style="Card.TLabel").grid(row=1, column=2, padx=(12, 8))
        self.folder_box = ttk.Combobox(self, textvariable=self.folder, state="disabled")
        self.folder_box.grid(row=1, column=3, columnspan=2, sticky="ew", pady=3)
        ttk.Label(self, text="Copy to", style="Card.TLabel").grid(row=2, column=0, sticky="w")
        self.destination_box = ttk.Combobox(self, textvariable=self.destination, values=DESTINATIONS, state="readonly", width=19)
        self.destination_box.grid(row=2, column=1, sticky="ew", pady=3)
        ttk.Label(self, text="Subfolder", style="Card.TLabel").grid(row=2, column=2, padx=(12, 8))
        self.custom_box = ttk.Entry(self, textvariable=self.custom)
        self.custom_box.grid(row=2, column=3, sticky="ew", pady=3)
        self.destination_button = ttk.Button(self, text="Browse", command=self.browse_destination)
        self.destination_button.grid(row=2, column=4, padx=(8, 0))
        self.hint_label = ttk.Label(self, textvariable=self.hint, style="CardMuted.TLabel", wraplength=840)
        self.hint_label.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(4, 1))
        self.remove_button = ttk.Button(self, text="Remove", command=lambda: self.app.remove_package(self))
        self.remove_button.grid(row=3, column=4, padx=(8, 0), pady=(4, 1))
        self.bind("<Configure>", lambda event: self.hint_label.configure(wraplength=max(300, event.width - 145)))
        self.archive.trace_add("write", self.archive_changed)
        for variable in (self.mode, self.folder, self.destination, self.custom):
            variable.trace_add("write", lambda *_: self.changed())
        self.apply_state()

    def changed(self):
        if self.mode.get() == MODES[1] and not self.folder.get() and self.contents:
            if self.contents.suggested_folder:
                self.folder.set(self.contents.suggested_folder)
        self.apply_state()
        self.refresh_hint()
        self.app.invalidate()

    def archive_changed(self, *_):
        self.scan_generation += 1
        self.contents = None
        self.folder.set("")
        self.folder_box["values"] = []
        self.app.invalidate()
        if self.scan_timer is not None:
            self.after_cancel(self.scan_timer)
        self.scan_timer = self.after(180, self.scan)
        self.refresh_hint()

    def scan(self):
        self.scan_timer = None
        path, generation = self.archive.get().strip(), self.scan_generation
        if not path:
            return
        self.hint.set("Reading ZIP folders…")

        def worker():
            try:
                result = inspect_archive(Path(path).expanduser())
                self.app.events.put(("zip_info", self, generation, result, None))
            except Exception as exc:
                self.app.events.put(("zip_info", self, generation, None, str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def stop_scan(self):
        self.scan_generation += 1
        if self.scan_timer is not None:
            self.after_cancel(self.scan_timer)
            self.scan_timer = None

    def accept_info(self, generation, contents, error):
        if generation != self.scan_generation:
            return
        self.contents = contents
        self.folder_box["values"] = contents.folders if contents else ()
        if error:
            self.hint.set("Could not read ZIP: " + error)
            return
        if not self.app.busy and self.mode.get() == MODES[1] and not self.folder.get() and contents.suggested_folder:
            self.folder.set(contents.suggested_folder)
        self.refresh_hint()

    def apply_state(self):
        disabled = self.app.busy
        for widget in (self.zip_button, self.destination_button):
            widget.configure(state="disabled" if disabled else "normal")
        self.zip_box.configure(state="disabled" if disabled else "normal")
        self.mode_box.configure(state="disabled" if disabled else "readonly")
        self.destination_box.configure(state="disabled" if disabled else "readonly")
        self.folder_box.configure(state="readonly" if not disabled and self.mode.get() == MODES[1] else "disabled")
        self.custom_box.configure(state="normal" if not disabled and self.destination.get() == DESTINATIONS[3] else "disabled")
        self.remove_button.configure(state="normal" if not disabled and len(self.app.cards) > MIN_PACKAGES else "disabled")

    def destination_path(self, strict=False):
        kind = self.destination.get()
        if kind == DESTINATIONS[0]:
            return ""
        if kind in DESTINATIONS[1:3]:
            data = self.app.data_folder.get()
            if strict:
                data = resolve_data_folder(validate_target(self.app.target.get()), data)
            if not data:
                raise InjectorError("Choose the game's data folder above.")
            return data + ("/Lang" if kind == DESTINATIONS[2] else "")
        if kind == DESTINATIONS[3]:
            custom = self.custom.get().strip()
            if not custom:
                raise InjectorError(f"ZIP {self.index + 1}: enter a subfolder or choose Game root.")
            return custom
        raise InjectorError("Choose a destination.")

    def rule(self):
        mode = "full" if self.mode.get() == MODES[0] else "folder"
        return PackageRule(mode, self.folder.get() if mode == "folder" else "", self.destination_path(strict=True))

    def refresh_hint(self):
        if not self.archive.get().strip():
            self.hint.set("Choose a ZIP file.")
            return
        source = "Entire ZIP" if self.mode.get() == MODES[0] else ((self.folder.get() + "/ contents") if self.folder.get() else "Choose a folder inside the ZIP")
        try:
            destination = self.destination_path()
            base = self.app.target.get().strip()
            target = str(Path(base) / destination) if base else "Choose the game folder above"
            self.hint.set(f"{source}  →  {target}")
        except InjectorError as exc:
            self.hint.set(f"{source}  →  {exc}")

    def browse_zip(self):
        path = filedialog.askopenfilename(parent=self.app, title=f"Select ZIP {self.index + 1}",
                                         initialdir=self.app.source.get() or str(BASE),
                                         filetypes=[("ZIP archives", "*.zip"), ("All files", "*.*")])
        if path:
            self.archive.set(path)

    def browse_destination(self):
        try:
            root = validate_target(self.app.target.get())
            path = filedialog.askdirectory(parent=self.app, title=f"Destination for ZIP {self.index + 1}", initialdir=str(root))
            if not path:
                return
            selected = Path(path).absolute()
            try:
                relative = selected.relative_to(root)
            except ValueError:
                raise InjectorError("Choose the game folder or a folder inside it.") from None
            if relative == Path("."):
                self.destination.set(DESTINATIONS[0])
            else:
                self.custom.set(relative.as_posix())
                self.destination.set(DESTINATIONS[3])
        except (OSError, InjectorError) as exc:
            messagebox.showerror("Destination folder", str(exc), parent=self.app)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Aura Injector 1.3")
        self.geometry(f"{min(1080, max(860, self.winfo_screenwidth()-90))}x{min(880, max(630, self.winfo_screenheight()-100))}")
        self.minsize(860, 630)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.events = queue.Queue()
        self.cancel_event = threading.Event()
        self.busy = False
        self.plan = None
        self.games = []
        self.cards = []
        self.zip_paths = []
        self.controls = []
        self.data_refresh = None
        self.animated_job = False
        self.pending_completion = None
        self.display_progress = self.progress_target = self.last_progress = 0.0
        self.source = tk.StringVar(value=str(BASE))
        self.target = tk.StringVar()
        self.data_folder = tk.StringVar()
        self.steam_choice = tk.StringVar()
        self.animation_enabled = tk.BooleanVar(value=True)
        self.percentage = tk.StringVar(value="0%")
        self.status = tk.StringVar(value="Add 1–10 ZIPs, then choose the source and destination for each.")
        self.package_count = tk.StringVar()
        self.summary = tk.StringVar(value="Run Check files to see exactly what will be copied and where.")
        self.make_style()
        self.make_ui()
        self.target.trace_add("write", self.target_changed)
        self.data_folder.trace_add("write", lambda *_: self.data_changed())
        self.load_source()
        self.scan_games()
        self.after(60, self.poll)
        self.after(16, self.animate_bar)

    def make_style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        s.configure("Muted.TLabel", foreground=MUTED)
        s.configure("Title.TLabel", font=("Segoe UI", 24, "bold"))
        s.configure("TLabelframe", background=CARD, bordercolor="#2b394a")
        s.configure("TLabelframe.Label", background=CARD, foreground=ACCENT, font=("Segoe UI", 11, "bold"))
        s.configure("Card.TLabel", background=CARD)
        s.configure("CardMuted.TLabel", background=CARD, foreground=MUTED, font=("Segoe UI", 9))
        s.configure("TButton", background="#29364a", foreground=TEXT, padding=(12, 7), borderwidth=0, font=("Segoe UI", 10))
        s.map("TButton", background=[("active", "#3a4e68"), ("disabled", "#202734")], foreground=[("disabled", "#748095")])
        s.configure("Accent.TButton", background=ACCENT, foreground="#0b2923", font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", "#a2f4dc"), ("disabled", "#293c3a")], foreground=[("disabled", "#81958e")])
        s.configure("TEntry", fieldbackground=CARD, foreground=TEXT, insertcolor=TEXT, padding=7)
        s.configure("TCombobox", fieldbackground=CARD, foreground=TEXT, background="#29364a", padding=6, arrowsize=15)
        s.map("TCombobox", fieldbackground=[("readonly", CARD), ("disabled", "#131923")], foreground=[("readonly", TEXT), ("disabled", "#647083")], selectbackground=[("readonly", CARD)])
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=CARD, foreground=MUTED, padding=(18, 8))
        s.map("TNotebook.Tab", background=[("selected", "#253c3a")], foreground=[("selected", ACCENT)])
        s.configure("TCheckbutton", background=BG, foreground=MUTED, font=("Segoe UI", 9))
        s.map("TCheckbutton", background=[("active", BG)])
        s.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=28, borderwidth=0, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background="#263141", foreground=TEXT, font=("Segoe UI", 10, "bold"), padding=7)
        s.map("Treeview", background=[("selected", "#284e48")])
        s.configure("Horizontal.TProgressbar", troughcolor=CARD, background=ACCENT, borderwidth=0, thickness=7)
        self.option_add("*TCombobox*Listbox.background", CARD)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", "#284e48")

    def control(self, widget, state="normal"):
        self.controls.append((widget, state))
        return widget

    def make_ui(self):
        main = ttk.Frame(self, padding=(22, 16))
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)
        header = ttk.Frame(main)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        ttk.Label(header, text="AURA INJECTOR", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="1.3  /  1–10 ZIPs · YOUR DESTINATIONS", foreground=ACCENT).pack(side="right")
        self.notebook = ttk.Notebook(main)
        self.notebook.grid(row=1, column=0, sticky="nsew")
        self.setup_page = ttk.Frame(self.notebook, padding=(10, 10, 10, 4))
        self.preview_page = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.setup_page, text="Packages & destinations")
        self.notebook.add(self.preview_page, text="File preview")
        self.setup_page.columnconfigure(0, weight=1)
        self.setup_page.rowconfigure(1, weight=1)
        settings = ttk.Frame(self.setup_page)
        settings.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        settings.columnconfigure(1, weight=1)
        for row, text in enumerate(("Game folder", "Steam games", "Data folder", "ZIP folder")):
            ttk.Label(settings, text=text, width=14).grid(row=row, column=0, sticky="w", pady=3)
        self.control(ttk.Entry(settings, textvariable=self.target)).grid(row=0, column=1, sticky="ew", pady=3)
        self.control(ttk.Button(settings, text="Browse", command=self.choose_target)).grid(row=0, column=2, padx=(8, 0))
        self.game_combo = self.control(ttk.Combobox(settings, textvariable=self.steam_choice, state="readonly"), "readonly")
        self.game_combo.grid(row=1, column=1, sticky="ew", pady=3)
        self.game_combo.bind("<<ComboboxSelected>>", self.select_game)
        self.control(ttk.Button(settings, text="Scan", command=self.scan_games)).grid(row=1, column=2, padx=(8, 0))
        self.data_combo = self.control(ttk.Combobox(settings, textvariable=self.data_folder, state="readonly"), "readonly")
        self.data_combo.grid(row=2, column=1, sticky="ew", pady=3)
        self.control(ttk.Button(settings, text="Browse", command=self.choose_data)).grid(row=2, column=2, padx=(8, 0))
        source_box = self.control(ttk.Entry(settings, textvariable=self.source))
        source_box.grid(row=3, column=1, sticky="ew", pady=3)
        source_box.bind("<Return>", lambda *_: self.load_source())
        self.control(ttk.Button(settings, text="Browse", command=self.choose_source)).grid(row=3, column=2, padx=(8, 0))
        self.control(ttk.Button(settings, text="Refresh", command=self.load_source)).grid(row=3, column=3, padx=(6, 0))
        package_actions = ttk.Frame(settings)
        package_actions.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self.add_button = ttk.Button(package_actions, text="Add ZIP", command=self.add_package)
        self.add_button.pack(side="left")
        ttk.Label(package_actions, textvariable=self.package_count, foreground=ACCENT).pack(side="left", padx=12)
        ttk.Label(package_actions, text="Each ZIP has its own copy rules.", style="Muted.TLabel").pack(side="right")
        scroll_area = ttk.Frame(self.setup_page)
        scroll_area.grid(row=1, column=0, sticky="nsew")
        scroll_area.rowconfigure(0, weight=1)
        scroll_area.columnconfigure(0, weight=1)
        self.canvas = tk.Canvas(scroll_area, bg=BG, highlightthickness=0, height=400)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(scroll_area, orient="vertical", command=self.canvas.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.cards_frame = ttk.Frame(self.canvas)
        window = self.canvas.create_window((0, 0), window=self.cards_frame, anchor="nw")
        self.cards_frame.columnconfigure(0, weight=1)
        self.cards_frame.bind("<Configure>", lambda *_: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(window, width=event.width))
        self.add_package()
        self.bind_all("<MouseWheel>", self.mousewheel, add="+")
        self.canvas.bind("<Button-4>", lambda *_: self.canvas.yview_scroll(-1, "units"))
        self.canvas.bind("<Button-5>", lambda *_: self.canvas.yview_scroll(1, "units"))
        self.preview_page.columnconfigure(0, weight=1)
        self.preview_page.rowconfigure(3, weight=1)
        self.summary_label = ttk.Label(self.preview_page, textvariable=self.summary, foreground=ACCENT, wraplength=950)
        self.summary_label.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        routes_frame = ttk.Frame(self.preview_page)
        routes_frame.grid(row=1, column=0, sticky="ew")
        routes_frame.columnconfigure(0, weight=1)
        self.routes = ttk.Treeview(routes_frame, columns=("zip", "source", "destination"), show="headings", height=3)
        for key, title, width in (("zip", "ZIP", 60), ("source", "Copy from ZIP", 300), ("destination", "Exact destination folder", 570)):
            self.routes.heading(key, text=title)
            self.routes.column(key, width=width, minwidth=50)
        self.routes.grid(row=0, column=0, sticky="ew")
        route_scrollbar = ttk.Scrollbar(routes_frame, orient="vertical", command=self.routes.yview)
        route_scrollbar.grid(row=0, column=1, sticky="ns")
        route_hbar = ttk.Scrollbar(routes_frame, orient="horizontal", command=self.routes.xview)
        route_hbar.grid(row=1, column=0, sticky="ew")
        self.routes.configure(yscrollcommand=route_scrollbar.set, xscrollcommand=route_hbar.set)
        ttk.Label(self.preview_page, text="Below: final files after conflicts. Later ZIPs in the list win.", style="Muted.TLabel").grid(row=2, column=0, sticky="w", pady=10)
        table = ttk.Frame(self.preview_page)
        table.grid(row=3, column=0, sticky="nsew")
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(table, columns=("zip", "from", "to", "action"), show="headings")
        for key, title, width in (("zip", "ZIP", 50), ("from", "Source inside ZIP", 270), ("to", "Destination relative to game root", 400), ("action", "Action", 180)):
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, minwidth=50)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        vbar.grid(row=0, column=1, sticky="ns")
        hbar = ttk.Scrollbar(table, orient="horizontal", command=self.tree.xview)
        hbar.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        footer = ttk.Frame(main)
        footer.grid(row=2, column=0, sticky="ew", pady=(12, 0))
        footer.columnconfigure(0, weight=1)
        actions = ttk.Frame(footer)
        actions.grid(row=0, column=0, sticky="ew")
        self.control(ttk.Button(actions, text="1. Check files", command=self.inspect)).pack(side="left")
        self.install_button = ttk.Button(actions, text="2. Inject", style="Accent.TButton", command=self.start_install, state="disabled")
        self.install_button.pack(side="left", padx=8)
        self.control(ttk.Button(actions, text="Restore last injection", command=self.start_restore)).pack(side="right")
        self.cancel_button = ttk.Button(actions, text="Cancel", command=self.cancel, state="disabled")
        self.cancel_button.pack(side="right", padx=8)
        options = ttk.Frame(footer)
        options.grid(row=1, column=0, sticky="ew", pady=(8, 6))
        self.control(ttk.Checkbutton(options, text="Animated injection", variable=self.animation_enabled)).pack(side="left")
        self.control(ttk.Button(options, text="Reset copy rules", command=self.reset_rules)).pack(side="right")
        progress = ttk.Frame(footer)
        progress.grid(row=2, column=0, sticky="ew")
        progress.columnconfigure(0, weight=1)
        self.bar = ttk.Progressbar(progress, maximum=100)
        self.bar.grid(row=0, column=0, sticky="ew")
        ttk.Label(progress, textvariable=self.percentage, foreground=ACCENT, width=5, anchor="e").grid(row=0, column=1)
        ttk.Label(footer, textvariable=self.status, style="Muted.TLabel", wraplength=950).grid(row=3, column=0, sticky="ew", pady=(7, 0))

    def sync_packages(self):
        for index, card in enumerate(self.cards):
            card.index = index
            card.configure(text=f"ZIP {index + 1}")
            card.grid_configure(row=index)
            card.apply_state()
        self.package_count.set(f"{len(self.cards)} / {MAX_PACKAGES} ZIPs")
        self.add_button.configure(state="normal" if not self.busy and len(self.cards) < MAX_PACKAGES else "disabled")

    def add_package(self):
        if self.busy or len(self.cards) >= MAX_PACKAGES:
            return None
        card = PackageCard(self.cards_frame, self, len(self.cards))
        card.zip_box["values"] = self.zip_paths
        card.grid(row=len(self.cards), column=0, sticky="ew", padx=(0, 5), pady=(0, 9))
        self.cards.append(card)
        self.sync_packages()
        self.invalidate()
        if len(self.cards) > 1:
            self.after_idle(self.canvas.yview_moveto, 1.0)
        return card

    def remove_package(self, card):
        if self.busy or len(self.cards) <= MIN_PACKAGES or not any(item is card for item in self.cards):
            return False
        card.stop_scan()
        self.cards.remove(card)
        card.destroy()
        self.sync_packages()
        self.invalidate()
        return True

    def accept_zip_info(self, card, generation, contents, error):
        # A scan may finish after a card was removed or its number changed.
        # Route it by object identity, never by its current list position.
        if any(item is card for item in self.cards):
            card.accept_info(generation, contents, error)

    def mousewheel(self, event):
        if self.notebook.select() != str(self.setup_page):
            return
        widget = event.widget
        # Let comboboxes use their own wheel behavior.
        if isinstance(widget, ttk.Combobox):
            return
        while widget is not None:
            if widget == self.canvas:
                self.canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
                return "break"
            widget = getattr(widget, "master", None)

    def invalidate(self):
        self.plan = None
        if hasattr(self, "install_button"):
            self.install_button.configure(state="disabled")
        self.summary.set("Settings changed. Run Check files before injecting.")
        for name in ("tree", "routes"):
            tree = getattr(self, name, None)
            if tree is not None and tree.get_children():
                tree.delete(*tree.get_children())

    def reset_rules(self):
        for card in self.cards:
            card.mode.set(MODES[0])
            card.folder.set("")
            card.destination.set(DESTINATIONS[0])
            card.custom.set("")
        self.notebook.select(self.setup_page)
        self.status.set("Copy rules reset: every ZIP uses Full archive → Game root. Selected ZIPs are kept.")

    def target_changed(self, *_):
        self.invalidate()
        self.data_folder.set("")
        self.data_combo["values"] = ()
        if self.data_refresh is not None:
            self.after_cancel(self.data_refresh)
        self.data_refresh = self.after(200, self.refresh_data)
        for card in self.cards:
            card.refresh_hint()

    def refresh_data(self):
        self.data_refresh = None
        if self.busy:
            return
        try:
            names = discover_data_folders(self.target.get()) if self.target.get().strip() else []
        except OSError:
            names = []
        self.data_combo["values"] = names
        if self.data_folder.get() not in names:
            suggested = [name for name in names if name.casefold().endswith("_data")]
            self.data_folder.set(suggested[0] if len(suggested) == 1 else "")

    def data_changed(self):
        self.invalidate()
        for card in self.cards:
            card.refresh_hint()

    def choose_target(self):
        path = filedialog.askdirectory(parent=self, title="Game folder containing the .exe")
        if path:
            self.steam_choice.set("")
            self.target.set(path)

    def choose_data(self):
        try:
            root = validate_target(self.target.get())
            path = filedialog.askdirectory(parent=self, title="Choose the game's data folder", initialdir=str(root))
            if path:
                selected = Path(path).absolute()
                if selected.parent != root:
                    raise InjectorError("Choose a data folder directly inside the game folder. Use Custom subfolder for other paths.")
                if self.data_refresh is not None:
                    self.after_cancel(self.data_refresh)
                    self.data_refresh = None
                self.data_combo["values"] = discover_data_folders(root)
                self.data_folder.set(selected.name)
        except (OSError, InjectorError) as exc:
            messagebox.showerror("Data folder", str(exc), parent=self)

    def choose_source(self):
        path = filedialog.askdirectory(parent=self, title="Folder containing your ZIP files", initialdir=str(BASE))
        if path:
            self.source.set(path)
            self.load_source()

    def load_source(self):
        self.invalidate()
        try:
            names = sorted((str(p.resolve()) for p in Path(self.source.get()).expanduser().iterdir()
                            if p.is_file() and p.suffix.lower() == ".zip"), key=str.casefold)
            self.zip_paths = names
            for card in self.cards:
                card.zip_box["values"] = names
                if card.archive.get():
                    card.scan_generation += 1
                    card.scan()
            self.status.set(f"{len(names)} ZIP files found. Select one for each slot, or use Browse.")
        except OSError as exc:
            messagebox.showerror("ZIP folder", str(exc), parent=self)

    def scan_games(self):
        def worker():
            try:
                games = discover_steam_games()
            except Exception:
                games = []
            self.events.put(("games", games))
        threading.Thread(target=worker, daemon=True).start()

    def select_game(self, *_):
        index = self.game_combo.current()
        if 0 <= index < len(self.games):
            self.target.set(self.games[index][1])

    def inspect(self):
        try:
            if not self.target.get().strip() or any(not card.archive.get().strip() for card in self.cards):
                raise InjectorError("Choose the game folder and a ZIP file for every active package. Remove any unused packages.")
            if self.data_refresh is not None:
                self.after_cancel(self.data_refresh)
                self.refresh_data()
            archives = [Path(card.archive.get().strip()).expanduser() for card in self.cards]
            rules = tuple(card.rule() for card in self.cards)
            target = self.target.get()
            self.invalidate()
            self.status.set("Checking selected source folders and exact destination paths…")
            self.run_job(lambda: make_plan(archives, target, self.cancel_event, rules=rules), self.show_plan)
        except (OSError, InjectorError) as exc:
            messagebox.showerror("Check files", str(exc), parent=self)

    def show_plan(self, plan):
        # Fill any automatically resolved inner folders before setting the plan.
        for card, rule in zip(self.cards, plan.rules):
            if rule.mode == "folder" and card.folder.get() != rule.source_folder:
                card.folder.set(rule.source_folder)
        self.invalidate()
        self.plan = plan
        conflicts, overwrite = set(plan.collisions), set(plan.overwrite)
        for index, rule in enumerate(plan.rules):
            source = "Full archive" if rule.mode == "full" else rule.source_folder + "/ (contents)"
            self.routes.insert("", "end", values=(index+1, source, str(plan.target / rule.destination)))
        for entry in plan.files[:5000]:
            action = "Replace + backup" if entry.relative in overwrite else "New file"
            if entry.relative in conflicts:
                action += " · ZIP conflict"
            self.tree.insert("", "end", values=(plan.archives.index(entry.archive)+1, entry.member, entry.relative, action))
        counts = ", ".join(f"ZIP {i+1}: {count}" for i, count in enumerate(plan.package_counts))
        self.summary.set(f"{len(plan.archives)} ZIPs · {len(plan.files)} final files · {size_text(plan.size)} · {len(plan.overwrite)} replacements · {len(plan.collisions)} conflicts\nSelected files: {counts}")
        self.install_button.configure(state="normal")
        self.notebook.select(self.preview_page)
        self.status.set("Check the source and destination paths. Close the game, then click Inject."
                        + (" Preview limited to the first 5,000 final files." if len(plan.files) > 5000 else ""))

    def start_install(self):
        plan = self.plan
        if plan is None:
            return
        text = (f"Install {len(plan.archives)} ZIPs using the rules shown in File preview?\n\n"
                f"Game folder:\n{plan.target}\n\n"
                f"{len(plan.files)} files; {len(plan.overwrite)} existing files backed up.\n"
                "Close the game. Start injection?")
        if not messagebox.askyesno("Confirm injection", text, parent=self):
            return
        animated = self.animation_enabled.get()
        def inject():
            progress = AnimatedProgress(self.progress, self.cancel_event, enabled=animated)
            progress("Preparing injection", 0, 100)
            return install(plan, progress, self.cancel_event)
        self.status.set("Preparing injection…")
        self.run_job(inject, self.installed, animated=animated)

    def installed(self, backup):
        self.invalidate()
        self.progress_target = self.display_progress = 100.0
        self.percentage.set("100%")
        self.summary.set("Injection complete. All selected files are in their configured destinations.")
        self.status.set("Injection complete. Original files were backed up.")
        messagebox.showinfo("Done", f"Files installed.\n\nBackup:\n{backup}", parent=self)

    def start_restore(self):
        try:
            target = self.target.get()
            if not target.strip():
                raise InjectorError("Choose the game folder first.")
            backup = latest_backup(target)
            if backup is None:
                raise InjectorError("No restorable Aura Injector backup was found for this game.")
            if not messagebox.askyesno("Restore last injection", f"Restore the state before the last injection?\n\n{backup.name}\n\nAdded files will be removed and replaced files restored. Close the game first.", parent=self):
                return
            self.invalidate()
            self.status.set("Checking backup and restoring files…")
            self.run_job(lambda: restore(target, backup, self.progress), self.restored, cancellable=False)
        except (OSError, InjectorError) as exc:
            messagebox.showerror("Restore", str(exc), parent=self)

    def restored(self, _):
        self.invalidate()
        self.progress_target = self.display_progress = 100.0
        self.summary.set("Original files restored.")
        self.status.set("Restore complete. The backup has been kept.")
        messagebox.showinfo("Done", "The state before the last injection has been restored.", parent=self)

    def run_job(self, job, success, cancellable=True, animated=False):
        self.busy, self.animated_job = True, animated
        self.pending_completion = None
        self.display_progress = self.progress_target = self.last_progress = 0.0
        self.cancel_event.clear()
        for widget, _ in self.controls:
            widget.configure(state="disabled")
        self.sync_packages()
        self.install_button.configure(state="disabled")
        self.cancel_button.configure(state="normal" if cancellable else "disabled")
        def worker():
            try:
                self.events.put(("done", success, job()))
            except Exception as exc:
                self.events.put(("error", exc, traceback.format_exc()))
        threading.Thread(target=worker, daemon=False).start()

    def finish_job(self):
        self.busy = self.animated_job = False
        for widget, state in self.controls:
            widget.configure(state=state)
        self.sync_packages()
        self.cancel_button.configure(state="disabled")

    def progress(self, text, current, total):
        now = time.monotonic()
        if now - self.last_progress >= 0.06 or current >= total:
            self.last_progress = now
            self.events.put(("progress", text, 100 * current / max(total, 1)))

    def animate_bar(self):
        self.display_progress = smooth_step(self.display_progress, self.progress_target) if self.busy and self.animated_job else self.progress_target
        self.bar["value"] = self.display_progress
        number = min(99, int(self.display_progress)) if self.busy and not self.pending_completion else int(self.display_progress)
        self.percentage.set(f"{number}%")
        if self.pending_completion and self.display_progress >= 100:
            success, result = self.pending_completion
            self.pending_completion = None
            self.finish_job()
            success(result)
        self.after(16, self.animate_bar)

    def poll(self):
        try:
            for _ in range(250):
                event = self.events.get_nowait()
                if event[0] == "progress":
                    self.status.set(event[1])
                    self.progress_target = max(self.progress_target, event[2])
                elif event[0] == "zip_info":
                    self.accept_zip_info(event[1], event[2], event[3], event[4])
                elif event[0] == "games":
                    self.games = event[1]
                    self.game_combo["values"] = [f"{name} — {path}" for name, path in self.games]
                    if not self.games:
                        self.steam_choice.set("No games found — browse to the game folder manually.")
                elif event[0] == "done":
                    if self.animated_job:
                        self.cancel_button.configure(state="disabled")
                        self.pending_completion = (event[1], event[2])
                        self.progress_target = 100.0
                    else:
                        self.finish_job()
                        event[1](event[2])
                elif event[0] == "error":
                    self.finish_job()
                    self.pending_completion = None
                    self.progress_target = self.display_progress = 0.0
                    self.invalidate()
                    if isinstance(event[1], Cancelled):
                        self.status.set("Cancelled. Original files have been preserved or restored.")
                    else:
                        self.status.set("Operation stopped. See the error message for details.")
                        try:
                            (BASE / "aura-injector-error.log").write_text(event[2], encoding="utf-8")
                        except OSError:
                            pass
                        messagebox.showerror("Aura Injector", str(event[1]), parent=self)
        except queue.Empty:
            pass
        self.after(60, self.poll)

    def cancel(self):
        self.cancel_event.set()
        self.cancel_button.configure(state="disabled")
        self.status.set("Cancelling… Applied changes will be rolled back.")

    def close(self):
        if self.busy:
            messagebox.showinfo("Operation in progress", "Wait for the operation to finish, or use Cancel.", parent=self)
        else:
            self.destroy()


def main():
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass
    App().mainloop()


if __name__ == "__main__":
    main()
