"""UI-to-installer rule mapping tests; no display server is required."""
import sys
import tempfile
import unittest
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest.mock import Mock, patch

project = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project if (project / "aura_core.py").exists() else project / "Aura-Injector"))
from aura_core import InjectorError, PackageRule
from aura_injector import App, DESTINATIONS, MODES, PackageCard


def variable(value):
    return SimpleNamespace(get=lambda: value)


class RuleControlsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "Game"
        self.root.mkdir()
        (self.root / "Game.exe").touch()
        (self.root / "Game_Data").mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def card(self, index=0, mode=MODES[0], folder="", destination=DESTINATIONS[0], custom="", data="Game_Data"):
        card = SimpleNamespace(index=index, mode=variable(mode), folder=variable(folder),
                               destination=variable(destination), custom=variable(custom),
                               app=SimpleNamespace(target=variable(str(self.root)), data_folder=variable(data)))
        card.destination_path = MethodType(PackageCard.destination_path, card)
        return card

    def test_english_destination_choices_map_to_distinct_paths_for_every_slot(self):
        for index in range(10):
            for choice, path in zip(DESTINATIONS, ("", "Game_Data", "Game_Data/Lang", "Mods/Extra")):
                with self.subTest(index=index, choice=choice):
                    card = self.card(index=index, mode=MODES[1], folder="Payload", destination=choice, custom="Mods/Extra")
                    self.assertEqual(PackageCard.rule(card), PackageRule("folder", "Payload", path))

    def test_full_mode_ignores_a_previous_inner_folder_choice(self):
        self.assertEqual(PackageCard.rule(self.card(folder="Old selection")), PackageRule())

    def test_custom_destination_does_not_require_a_data_folder(self):
        (self.root / "Game_Data").rmdir()
        card = self.card(destination=DESTINATIONS[3], custom="Other/Place", data="")
        self.assertEqual(PackageCard.rule(card).destination, "Other/Place")

    def test_empty_custom_destination_requires_a_choice(self):
        with self.assertRaises(InjectorError):
            PackageCard.rule(self.card(destination=DESTINATIONS[3], custom=""))

    def test_data_destination_requires_an_existing_folder(self):
        with self.assertRaises(InjectorError):
            PackageCard.rule(self.card(destination=DESTINATIONS[1], data="Missing"))


class WidgetStub(dict):
    def configure(self, **options):
        self.update(options)

    grid = grid_configure = configure


class CardStub(WidgetStub):
    apply_state = PackageCard.apply_state

    def __init__(self, parent, app, index):
        super().__init__()
        self.app, self.index = app, index
        self.archive = variable(f"package-{index}.zip")
        self.mode = variable(MODES[0])
        self.folder = variable("")
        self.destination = variable(DESTINATIONS[0])
        self.custom = variable("")
        for name in ("zip_button", "destination_button", "zip_box", "mode_box", "destination_box",
                     "folder_box", "custom_box", "remove_button"):
            setattr(self, name, WidgetStub())
        self.stop_scan = Mock()
        self.destroy = Mock()
        self.accept_info = Mock()


class PackageListTests(unittest.TestCase):
    def setUp(self):
        self.app = SimpleNamespace(cards=[], busy=False, cards_frame=None, zip_paths=["available.zip"],
                                   add_button=WidgetStub(), package_count=Mock(), invalidate=Mock(),
                                   after_idle=Mock(), canvas=Mock())
        for name in ("add_package", "remove_package", "sync_packages", "accept_zip_info"):
            setattr(self.app, name, MethodType(getattr(App, name), self.app))
        self.factory = patch("aura_injector.PackageCard", CardStub)
        self.factory.start()
        self.addCleanup(self.factory.stop)

    def test_list_starts_with_one_and_enforces_both_bounds(self):
        app = self.app
        first = app.add_package()
        self.assertEqual(len(app.cards), 1)
        self.assertFalse(app.remove_package(first))
        self.assertEqual(first.remove_button["state"], "disabled")
        for _ in range(9):
            card = app.add_package()
            self.assertEqual(card.zip_box["values"], ["available.zip"])
        self.assertEqual(len(app.cards), 10)
        self.assertEqual(app.add_button["state"], "disabled")
        self.assertIsNone(app.add_package())
        app.package_count.set.assert_called_with("10 / 10 ZIPs")
        self.assertTrue(app.remove_package(app.cards[-1]))
        self.assertEqual(app.add_button["state"], "normal")
        self.assertEqual(len(app.cards), 9)
        for card in list(app.cards[1:]):
            app.remove_package(card)
        self.assertIs(app.cards[0], first)
        self.assertEqual(first.remove_button["state"], "disabled")

    def test_removing_middle_card_keeps_survivors_settings_and_renumbers(self):
        app = self.app
        first, removed, last = (app.add_package() for _ in range(3))
        last.mode = variable(MODES[1])
        last.folder = variable("Release/Windows")
        last.destination = variable(DESTINATIONS[3])
        last.custom = variable("Mods/Extra")
        app.invalidate.reset_mock()
        self.assertTrue(app.remove_package(removed))
        removed.stop_scan.assert_called_once()
        removed.destroy.assert_called_once()
        self.assertEqual([id(card) for card in app.cards], [id(first), id(last)])
        self.assertEqual(last.index, 1)
        self.assertEqual(last["text"], "ZIP 2")
        self.assertEqual(last["row"], 1)
        self.assertEqual((last.archive.get(), last.mode.get(), last.folder.get(), last.destination.get(), last.custom.get()),
                         ("package-2.zip", MODES[1], "Release/Windows", DESTINATIONS[3], "Mods/Extra"))
        app.invalidate.assert_called_once()

    def test_background_scan_results_cannot_land_on_another_card_after_removal(self):
        app = self.app
        first, removed, last = (app.add_package() for _ in range(3))
        app.remove_package(removed)
        # The removed card's old number is now used by last.
        self.assertEqual(last.index, removed.index)
        app.accept_zip_info(removed, 7, "old contents", None)
        removed.accept_info.assert_not_called()
        last.accept_info.assert_not_called()
        app.accept_zip_info(last, 8, "correct contents", None)
        last.accept_info.assert_called_once_with(8, "correct contents", None)
        first.accept_info.assert_not_called()

    def test_busy_operation_locks_list_and_recovers_correct_button_states(self):
        app = self.app
        first = app.add_package()
        app.add_package()
        app.busy = True
        app.sync_packages()
        self.assertIsNone(app.add_package())
        self.assertFalse(app.remove_package(first))
        self.assertEqual(app.add_button["state"], "disabled")
        self.assertTrue(all(card.remove_button["state"] == "disabled" for card in app.cards))
        self.assertEqual(len(app.cards), 2)
        app.busy = False
        app.sync_packages()
        self.assertEqual(app.add_button["state"], "normal")
        self.assertTrue(all(card.remove_button["state"] == "normal" for card in app.cards))


if __name__ == "__main__":
    unittest.main(verbosity=2)
