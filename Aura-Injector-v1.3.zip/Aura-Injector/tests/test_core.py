import importlib.util
import json
import os
import stat
import sys
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

project = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project if (project / "aura_core.py").exists() else project / "Aura-Injector"))
import aura_core as core


class InjectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.game = self.base / "Tesztjáték"
        self.game.mkdir()
        (self.game / "Game.exe").write_bytes(b"original game")
        self.data = self.game / "Game_Data"
        self.data.mkdir()
        self.lang = self.data / "Lang"
        (self.game / "shared.txt").write_text("old", encoding="utf-8")
        self.a = self.base / "1.zip"
        self.b = self.base / "2.zip"
        self.c = self.base / "3.zip"
        self.write(self.a, {"plugins/a.txt": "first", "shared.txt": "one"})
        self.write(self.b, {"Package2/plugins/b.txt": "second", "Package2/shared.txt": "two"})
        self.write(self.c, {"Magyarítás/shared.txt": "three", "Magyarítás/locale/hu.txt": "árvíztűrő"})

    def tearDown(self):
        self.temp.cleanup()

    def write(self, path, entries, compression=zipfile.ZIP_DEFLATED):
        with zipfile.ZipFile(path, "w", compression=compression) as zf:
            for name, content in entries.items():
                zf.writestr(name, content)

    def plan(self, data_folder=None):
        data = core.resolve_data_folder(self.game, data_folder)
        rules = (core.PackageRule(), core.PackageRule("folder"), core.PackageRule("folder", "", data))
        return core.make_plan([self.a, self.b, self.c], self.game, rules=rules)

    def snapshot(self):
        return {str(p.relative_to(self.game)): p.read_bytes()
                for p in self.game.rglob("*") if p.is_file()
                and core.BACKUPS not in p.parts and p.name != core.LOCK}

    def test_three_archives_strip_one_level_merge_and_restore(self):
        before = self.snapshot()
        plan = self.plan()
        self.assertEqual(plan.rules[2].source_folder, "Magyarítás")
        self.assertEqual(plan.collisions, ["shared.txt"])
        self.assertEqual(plan.overwrite, ["shared.txt"])
        backup = core.install(plan)
        self.assertEqual((self.game / "shared.txt").read_text(), "two")
        self.assertEqual((self.data / "shared.txt").read_text(), "three")
        self.assertEqual(plan.target / plan.rules[2].destination, self.data)
        self.assertEqual((self.data / "locale/hu.txt").read_text(), "árvíztűrő")
        self.assertTrue((self.game / "plugins/a.txt").exists())
        self.assertTrue((self.game / "plugins/b.txt").exists())
        self.assertFalse((self.game / "Magyarítás").exists())
        self.assertEqual(core.latest_backup(self.game), backup)
        self.assertEqual((backup / "original/shared.txt").read_text(), "old")
        core.restore(self.game, backup)
        self.assertEqual(before, self.snapshot())
        self.assertFalse((self.game / "plugins").exists())
        self.assertFalse(self.lang.exists())
        self.assertTrue(self.data.is_dir())
        self.assertIsNone(core.latest_backup(self.game))

    def test_preserve_empty_directories(self):
        self.write(self.a, {"empty/": "", "file.txt": "data"})
        self.write(self.c, {"Outer/nested/empty/": "", "Outer/x.txt": "x"})
        backup = core.install(self.plan())
        self.assertTrue((self.game / "empty").is_dir())
        self.assertTrue((self.data / "nested/empty").is_dir())
        core.restore(self.game, backup)
        self.assertFalse((self.game / "empty").exists())

    def test_strip_exactly_one_level(self):
        self.write(self.c, {"Root/BepInEx/Translation/hu/file.txt": "Hungarian"})
        core.install(self.plan())
        self.assertTrue((self.data / "BepInEx/Translation/hu/file.txt").is_file())
        self.assertFalse((self.game / "Translation").exists())

    def test_wrapper_rejects_multiple_roots_and_root_file(self):
        for entries in [{"A/x.txt": "x", "B/y.txt": "y"}, {"root.txt": "x"},
                        {"A/x.txt": "x", "root.txt": "y"}]:
            with self.subTest(entries=entries):
                self.write(self.c, entries)
                with self.assertRaises(core.InjectorError):
                    self.plan()

    def test_duplicates_and_empty_archives_rejected(self):
        with self.assertRaises(core.InjectorError):
            core.make_plan([self.a, self.a, self.c], self.game)
        self.write(self.a, {"folder/": ""})
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_path_traversal_and_windows_special_paths_rejected(self):
        for bad in ["../escape.txt", "/outside.txt", "C:/outside.txt", "safe/../../x",
                    "safe\\..\\escape", "safe/file:stream", "NUL.txt", "con", "LPT1.dat",
                    "bad./x", "bad /x", "safe//x", "foo?bar", "safe/./file"]:
            with self.subTest(path=bad):
                self.write(self.a, {bad: "bad"})
                with self.assertRaises(core.InjectorError):
                    self.plan()
        self.assertFalse((self.base / "escape.txt").exists())

    def test_reserved_backup_and_lock_names_rejected(self):
        for bad in [core.BACKUPS + "/manifest.json", core.LOCK, "Outer/" + core.BACKUPS + "/x"]:
            with self.subTest(path=bad):
                if bad.startswith("Outer/"):
                    self.write(self.c, {bad: "bad"})
                else:
                    self.write(self.a, {bad: "bad"})
                with self.assertRaises(core.InjectorError):
                    self.plan()

    def test_zip_symlinks_rejected(self):
        info = zipfile.ZipInfo("link")
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(self.a, "w") as zf:
            zf.writestr(info, "../outside")
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_existing_destination_symlink_rejected(self):
        outside = self.base / "outside"
        outside.mkdir()
        (self.game / "plugins").symlink_to(outside, target_is_directory=True)
        with self.assertRaises(core.InjectorError):
            self.plan()
        self.assertEqual(list(outside.iterdir()), [])

    def test_backup_folder_symlink_rejected(self):
        outside = self.base / "outside"
        outside.mkdir()
        (self.game / core.BACKUPS).symlink_to(outside, target_is_directory=True)
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_case_insensitive_zip_conflicts(self):
        self.write(self.a, {"Plugins/ONE.txt": "first"})
        self.write(self.b, {"Package2/plugins/one.TXT": "second"})
        plan = self.plan()
        self.assertIn("Plugins/ONE.txt", plan.collisions)
        core.install(plan)
        self.assertEqual((self.game / "Plugins/ONE.txt").read_text(), "second")

    def test_file_directory_collision_rejected(self):
        self.write(self.a, {"plugins": "file"})
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_existing_file_blocks_directory(self):
        (self.game / "plugins").write_text("file")
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_cancel_before_install_changes_nothing(self):
        before = self.snapshot()
        cancel = threading.Event()
        cancel.set()
        with self.assertRaises(core.Cancelled):
            core.install(self.plan(), cancel=cancel)
        self.assertEqual(before, self.snapshot())
        self.assertFalse((self.game / core.LOCK).exists())

    def test_cancel_mid_install_rolls_back(self):
        before = self.snapshot()
        cancel = threading.Event()

        def progress(text, *_):
            if text.startswith("Injecting: "):
                cancel.set()

        with self.assertRaises(core.Cancelled):
            core.install(self.plan(), progress, cancel)
        self.assertEqual(before, self.snapshot())
        self.assertIsNone(core.latest_backup(self.game))

    def test_copy_failure_rolls_back_previous_writes(self):
        before = self.snapshot()
        original = core._atomic_copy
        count = [0]

        def fail_third(*args):
            count[0] += 1
            if count[0] == 3:
                raise PermissionError("simulated locked file")
            return original(*args)

        with patch.object(core, "_atomic_copy", side_effect=fail_third):
            with self.assertRaises(PermissionError):
                core.install(self.plan())
        self.assertEqual(before, self.snapshot())

    def test_changed_archive_invalidates_preview(self):
        plan = self.plan()
        self.write(self.a, {"somethingelse.txt": "changed"})
        with self.assertRaises(core.InjectorError):
            core.install(plan)
        self.assertEqual((self.game / "shared.txt").read_text(), "old")

    def test_crc_failure_happens_before_game_changes(self):
        self.write(self.a, {"bad.txt": "CONTENT_TO_CORRUPT"}, zipfile.ZIP_STORED)
        payload = self.a.read_bytes().replace(b"CONTENT_TO_CORRUPT", b"CONTENT_TO_CORRUPX")
        self.a.write_bytes(payload)
        before = self.snapshot()
        with self.assertRaises(zipfile.BadZipFile):
            core.install(self.plan())
        self.assertEqual(before, self.snapshot())

    def test_low_disk_space_rejected_before_changes(self):
        before = self.snapshot()
        with patch.object(core.shutil, "disk_usage", return_value=type("Disk", (), {"free": 1})()):
            with self.assertRaises(core.InjectorError):
                core.install(self.plan())
        self.assertEqual(before, self.snapshot())

    def test_restore_protects_later_user_changes(self):
        backup = core.install(self.plan())
        path = self.data / "locale/hu.txt"
        path.write_text("user edit")
        before = self.snapshot()
        with self.assertRaises(core.InjectorError):
            core.restore(self.game, backup)
        self.assertEqual(before, self.snapshot())

    def test_restore_rejects_corrupted_backup_before_changes(self):
        backup = core.install(self.plan())
        (backup / "original/shared.txt").write_text("corrupted")
        before = self.snapshot()
        with self.assertRaises(core.InjectorError):
            core.restore(self.game, backup)
        self.assertEqual(before, self.snapshot())

    def test_restore_can_retry_after_failure(self):
        before = self.snapshot()
        backup = core.install(self.plan())
        with patch.object(core, "_atomic_copy", side_effect=PermissionError("locked")):
            with self.assertRaises(PermissionError):
                core.restore(self.game, backup)
        self.assertEqual(core._read_state(backup), "restoring")
        core.restore(self.game, backup)
        self.assertEqual(before, self.snapshot())

    def test_latest_first_for_multiple_installs(self):
        original = self.snapshot()
        first = core.install(self.plan())
        state_one = self.snapshot()
        self.write(self.c, {"Magyarítás/shared.txt": "four", "Magyarítás/new.txt": "new"})
        second = core.install(self.plan())
        with self.assertRaises(core.InjectorError):
            core.restore(self.game, first)
        core.restore(self.game, second)
        self.assertEqual(state_one, self.snapshot())
        core.restore(self.game, first)
        self.assertEqual(original, self.snapshot())

    def test_lock_stops_second_installer(self):
        (self.game / core.LOCK).write_text("999")
        with self.assertRaises(core.InjectorError):
            core.install(self.plan())
        self.assertTrue((self.game / core.LOCK).exists())

    def test_target_must_be_game_not_steam_or_common(self):
        common = self.base / "common"
        common.mkdir()
        (common / "Game.exe").touch()
        with self.assertRaises(core.InjectorError):
            core.validate_target(common)
        (self.game / "steam.exe").touch()
        with self.assertRaises(core.InjectorError):
            core.validate_target(self.game)

    def test_macos_metadata_is_ignored(self):
        self.write(self.c, {"Outer/hu.txt": "hu", "__MACOSX/._hu.txt": "meta", ".DS_Store": "meta"})
        plan = self.plan()
        self.assertEqual(plan.rules[2].source_folder, "Outer")
        self.assertNotIn(".DS_Store", [e.relative for e in plan.files])

    def test_nonempty_directory_entries_rejected(self):
        self.write(self.a, {"dir/": "bad", "file.txt": "okay"})
        with self.assertRaises(core.InjectorError):
            self.plan()

    def test_backslash_zip_paths(self):
        self.write(self.c, {"Outer\\lang\\hu.txt": "text"})
        core.install(self.plan())
        self.assertEqual((self.data / "lang/hu.txt").read_text(), "text")

    def test_nonempty_new_folders_are_preserved_on_restore(self):
        backup = core.install(self.plan())
        (self.game / "plugins/user-created.txt").write_text("keep")
        core.restore(self.game, backup)
        self.assertEqual((self.game / "plugins/user-created.txt").read_text(), "keep")

    def test_zip_three_never_copies_into_game_root(self):
        self.write(self.c, {"Payload/only-third.txt": "language"})
        core.install(self.plan())
        self.assertEqual((self.data / "only-third.txt").read_text(), "language")
        self.assertFalse((self.game / "only-third.txt").exists())
        self.assertFalse((self.game / "Payload").exists())

    def test_zip_three_replaces_and_restores_existing_language_file(self):
        (self.data / "shared.txt").write_text("original language")
        before = self.snapshot()
        backup = core.install(self.plan())
        self.assertEqual((self.data / "shared.txt").read_text(), "three")
        self.assertEqual((backup / "original/Game_Data/shared.txt").read_text(), "original language")
        core.restore(self.game, backup)
        self.assertEqual(before, self.snapshot())

    def test_custom_data_folder_with_unicode_and_spaces(self):
        custom = self.game / "Adatmappa Neve ő"
        custom.mkdir()
        plan = self.plan(data_folder=custom.name)
        backup = core.install(plan)
        self.assertEqual((custom / "locale/hu.txt").read_text(), "árvíztűrő")
        self.assertFalse(self.lang.exists())
        core.restore(self.game, backup)
        self.assertTrue(custom.exists())
        self.assertFalse((custom / "Lang").exists())

    def test_ambiguous_data_folder_requires_selection_and_selection_is_kept(self):
        (self.game / "Another_Data").mkdir()
        with self.assertRaises(core.InjectorError):
            self.plan()
        plan = self.plan(data_folder="Game_Data")
        core.install(plan)
        self.assertTrue((self.data / "locale/hu.txt").is_file())
        self.assertFalse((self.game / "Another_Data/locale").exists())

    def test_missing_data_folder_is_not_guessed(self):
        self.data.rmdir()
        with self.assertRaises(core.InjectorError):
            self.plan()
        with self.assertRaises(core.InjectorError):
            self.plan(data_folder="Missing")

    def test_data_folder_must_be_an_existing_direct_child(self):
        (self.data / "Nested").mkdir()
        for name in ["../Outside", "Game_Data/Nested", str(self.data), core.BACKUPS]:
            with self.subTest(name=name), self.assertRaises(core.InjectorError):
                self.plan(data_folder=name)

    def test_linked_language_folder_is_rejected(self):
        outside = self.base / "outside-language"
        outside.mkdir()
        self.lang.symlink_to(outside, target_is_directory=True)
        rules = (core.PackageRule(), core.PackageRule("folder"), core.PackageRule("folder", "", "Game_Data/Lang"))
        with self.assertRaises(core.InjectorError):
            core.make_plan([self.a, self.b, self.c], self.game, rules=rules)
        self.assertEqual(list(outside.iterdir()), [])

    def test_all_three_zips_can_collide_at_language_destination(self):
        self.write(self.a, {"Game_Data/shared.txt": "first"})
        self.write(self.b, {"Package2/Game_Data/shared.txt": "second"})
        plan = self.plan()
        self.assertIn("Game_Data/shared.txt", plan.collisions)
        core.install(plan)
        self.assertEqual((self.data / "shared.txt").read_text(), "three")

    def test_cancel_during_final_animation_rolls_back(self):
        from aura_progress import AnimatedProgress
        before = self.snapshot()
        cancel = threading.Event()
        animated = AnimatedProgress(lambda *_: None, cancel)

        def hold(text, checkpoint, duration):
            if checkpoint == 92:
                cancel.set()
                raise core.Cancelled("Operation cancelled.")

        with patch.object(animated, "_hold", side_effect=hold):
            with self.assertRaises(core.Cancelled):
                core.install(self.plan(), animated, cancel)
        self.assertEqual(before, self.snapshot())

    def test_folder_listing_includes_nested_and_implicit_folders(self):
        self.write(self.b, {"Bundle/tools/bin/a.dll": "x", "Bundle/empty/": ""})
        contents = core.inspect_archive(self.b)
        self.assertEqual(contents.suggested_folder, "Bundle")
        self.assertEqual(contents.file_count, 1)
        self.assertEqual(set(contents.folders), {"Bundle", "Bundle/tools", "Bundle/tools/bin", "Bundle/empty"})

    def test_explicit_inner_folder_excludes_sibling_folders_and_readme(self):
        self.write(self.b, {"README.txt": "skip", "Windows/x64/plugin.dll": "take",
                            "Windows/x86/plugin.dll": "skip", "Linux/plugin.so": "skip"})
        rules = (core.PackageRule(), core.PackageRule("folder", "Windows/x64"),
                 core.PackageRule("folder", "", "Game_Data"))
        plan = core.make_plan([self.a, self.b, self.c], self.game, rules=rules)
        self.assertEqual(plan.package_counts[1], 1)
        core.install(plan)
        self.assertEqual((self.game / "plugin.dll").read_text(), "take")
        for name in ("README.txt", "Windows", "Linux"):
            self.assertFalse((self.game / name).exists())

    def test_all_archives_can_use_full_mode_without_a_data_folder(self):
        self.data.rmdir()
        plan = core.make_plan([self.a, self.b, self.c], self.game, rules=(core.PackageRule(),) * 3)
        core.install(plan)
        self.assertEqual((self.game / "Package2/plugins/b.txt").read_text(), "second")
        self.assertEqual((self.game / "Magyarítás/locale/hu.txt").read_text(), "árvíztűrő")

    def test_each_slot_supports_both_copy_modes_and_all_destination_types(self):
        # Behavioral matrix: 10 independent slots x 2 copy modes x 4 destinations.
        paths = [self.base / f"matrix-{i}.zip" for i in range(10)]
        for index, path in enumerate(paths):
            self.write(path, {f"Outer{index}/nested/file{index}.txt": f"payload-{index}"})
        before = self.snapshot()
        for slot in range(10):
            for mode in ("full", "folder"):
                for destination in ("", "Game_Data", "Game_Data/Lang", "Mods/Custom Place"):
                    with self.subTest(slot=slot, mode=mode, destination=destination):
                        rules = [core.PackageRule("full", "", f"Side{i}") for i in range(10)]
                        rules[slot] = core.PackageRule(mode, f"Outer{slot}" if mode == "folder" else "", destination)
                        plan = core.make_plan(paths, self.game, rules=rules)
                        expected = self.game / destination
                        if mode == "full":
                            expected = expected / f"Outer{slot}"
                        expected = expected / f"nested/file{slot}.txt"
                        backup = core.install(plan)
                        self.assertEqual(expected.read_text(), f"payload-{slot}")
                        core.restore(self.game, backup)
                        self.assertEqual(before, self.snapshot())
                        self.assertFalse((self.game / "Mods").exists())
                        self.assertFalse(self.lang.exists())

    def test_custom_destination_paths_cannot_escape_game_root(self):
        before = self.snapshot()
        for destination in ("../outside", "/outside", "C:/outside", "good/../../escape", core.BACKUPS, core.LOCK):
            rules = (core.PackageRule("full", "", destination), core.PackageRule("folder"), core.PackageRule("folder", "", "Game_Data"))
            with self.subTest(destination=destination), self.assertRaises(core.InjectorError):
                core.make_plan([self.a, self.b, self.c], self.game, rules=rules)
        self.assertEqual(before, self.snapshot())

    def test_invalid_source_folder_and_empty_source_are_rejected(self):
        self.write(self.b, {"Payload/file.txt": "x", "Empty/": ""})
        for source in ("Missing", "Empty", "../Payload", "Payload/file.txt"):
            rules = (core.PackageRule(), core.PackageRule("folder", source), core.PackageRule("folder", "", "Game_Data"))
            with self.subTest(source=source), self.assertRaises(core.InjectorError):
                core.make_plan([self.a, self.b, self.c], self.game, rules=rules)

    def test_rule_validation_rejects_unknown_or_conflicting_modes(self):
        for rule in (core.PackageRule("typo"), core.PackageRule("full", "Unexpected")):
            with self.assertRaises(core.InjectorError):
                core.make_plan([self.a, self.b, self.c], self.game, rules=(rule, core.PackageRule("folder"), core.PackageRule("folder", "", "Game_Data")))
        with self.assertRaises(core.InjectorError):
            core.make_plan([self.a, self.b, self.c], self.game, rules=())

    def test_nested_source_with_backslashes_is_normalized(self):
        self.write(self.b, {"Bundle/Windows/Payload/plugin.dll": "x", "other.txt": "skip"})
        rules = (core.PackageRule(), core.PackageRule("folder", "Bundle\\Windows\\Payload", "Mods\\Extra"), core.PackageRule("folder", "", "Game_Data"))
        plan = core.make_plan([self.a, self.b, self.c], self.game, rules=rules)
        self.assertEqual(plan.rules[1], core.PackageRule("folder", "Bundle/Windows/Payload", "Mods/Extra"))
        core.install(plan)
        self.assertEqual((self.game / "Mods/Extra/plugin.dll").read_text(), "x")

    def test_custom_destination_symlink_is_rejected(self):
        outside = self.base / "outside"
        outside.mkdir()
        (self.game / "Redirect").symlink_to(outside, target_is_directory=True)
        rules = (core.PackageRule("full", "", "Redirect"), core.PackageRule("folder"), core.PackageRule("folder", "", "Game_Data"))
        with self.assertRaises(core.InjectorError):
            core.make_plan([self.a, self.b, self.c], self.game, rules=rules)
        self.assertEqual(list(outside.iterdir()), [])

    def test_manifest_records_resolved_rules(self):
        plan = self.plan()
        backup = core.install(plan)
        data = json.loads((backup / "manifest.json").read_text())
        self.assertEqual(data["injector_version"], "1.3")
        self.assertEqual(data["injector_name"], "Aura Injector")
        self.assertEqual(data["rules"][1], {"mode": "folder", "source_folder": "Package2", "destination": ""})
        self.assertEqual(data["rules"][2]["destination"], "Game_Data")

    def test_every_supported_package_count_installs_and_restores_without_data_folder(self):
        self.data.rmdir()
        before = self.snapshot()
        paths = [self.base / f"package-{i}.zip" for i in range(10)]
        for index, path in enumerate(paths):
            self.write(path, {f"Folder{index}/new.txt": str(index), "shared.txt": str(index)})
        for count in range(1, 11):
            with self.subTest(count=count):
                # Use a generator to check that input is consumed only once.
                plan = core.make_plan((path for path in paths[:count]), self.game)
                self.assertEqual(len(plan.rules), count)
                self.assertEqual(plan.rules, (core.PackageRule(),) * count)
                self.assertEqual(plan.package_counts, (2,) * count)
                backup = core.install(plan)
                self.assertEqual((self.game / "shared.txt").read_text(), str(count - 1))
                for index in range(count):
                    self.assertEqual((self.game / f"Folder{index}/new.txt").read_text(), str(index))
                core.restore(self.game, backup)
                self.assertEqual(self.snapshot(), before)
                self.assertFalse(any(self.game.glob("Folder*")))

    def test_package_count_outside_one_to_ten_is_rejected_before_reading_archives(self):
        before = self.snapshot()
        for count in (0, 11):
            with self.subTest(count=count), self.assertRaisesRegex(core.InjectorError, "between 1 and 10"):
                core.make_plan([self.base / f"nonexistent-{i}.zip" for i in range(count)], self.game)
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.game / core.BACKUPS).exists())

    def test_each_active_package_requires_exactly_one_valid_rule(self):
        for count in (1, 2, 10):
            paths = [self.base / f"nonexistent-{i}.zip" for i in range(count)]
            for rules in ((core.PackageRule(),) * (count - 1), (core.PackageRule(),) * (count + 1), (None,) * count):
                with self.subTest(count=count, rules=rules), self.assertRaisesRegex(core.InjectorError, "one copy rule"):
                    core.make_plan(paths, self.game, rules=rules)

    def test_tenth_package_cancellation_restores_all_nine_earlier_packages(self):
        before = self.snapshot()
        paths = [self.base / f"cancel-{i}.zip" for i in range(10)]
        for index, path in enumerate(paths):
            self.write(path, {f"new-{index}.txt": str(index)})
        cancel = threading.Event()
        installed = []

        def progress(message, current, total):
            if message.startswith("Injecting: "):
                installed.append(message)
                if len(installed) == 9:
                    cancel.set()

        with self.assertRaises(core.Cancelled):
            core.install(core.make_plan(paths, self.game), progress, cancel)
        self.assertEqual(len(installed), 9)
        self.assertEqual(self.snapshot(), before)


class AnimationTests(unittest.TestCase):
    def test_disabled_animation_has_no_wait(self):
        from aura_progress import AnimatedProgress
        emitted = []
        progress = AnimatedProgress(lambda *args: emitted.append(args), threading.Event(), enabled=False)
        with patch.object(progress, "_hold") as hold:
            progress("Extracting", 80, 100)
            progress("Injection complete", 100, 100)
            hold.assert_not_called()
        self.assertEqual([item[1] for item in emitted], [80, 100])

    def test_each_checkpoint_is_used_at_most_once(self):
        from aura_progress import AnimatedProgress
        progress = AnimatedProgress(lambda *_: None, threading.Event())
        with patch.object(progress, "_hold") as hold:
            for value in (0, 0, 8, 65, 65, 90, 99, 100):
                progress("Working", value, 100)
            self.assertEqual([call.args[1] for call in hold.call_args_list], [0, 30, 64, 92])

    def test_hold_is_immediately_cancellable(self):
        from aura_progress import AnimatedProgress
        cancel = threading.Event()
        progress = AnimatedProgress(lambda *_: cancel.set(), cancel)
        with self.assertRaises(core.Cancelled):
            progress._hold("Preparing", 0, 1.0)

    def test_success_event_cannot_cancel_committed_files(self):
        from aura_progress import AnimatedProgress
        cancel = threading.Event()
        cancel.set()
        emitted = []
        progress = AnimatedProgress(lambda *args: emitted.append(args), cancel)
        progress("Injection complete", 100, 100)
        self.assertEqual(emitted[0][1], 100)

    def test_smoothing_is_monotonic_and_does_not_get_ahead(self):
        from aura_progress import smooth_step
        displayed = 0
        for target in (30, 64, 99, 100):
            for _ in range(200):
                updated = smooth_step(displayed, target)
                self.assertGreaterEqual(updated, displayed)
                self.assertLessEqual(updated, target)
                displayed = updated
            self.assertEqual(displayed, target)


if __name__ == "__main__":
    unittest.main(verbosity=2)
