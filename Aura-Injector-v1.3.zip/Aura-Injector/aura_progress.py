"""Short optional presentation pauses, run on the install worker thread."""
from __future__ import annotations

import random
import time

from aura_core import Cancelled


class AnimatedProgress:
    # A few brief holds per installation, never a delay for every file.
    CHECKPOINTS = ((0, 0.60, 0.85), (30, 0.35, 0.55),
                   (64, 0.40, 0.65), (92, 0.50, 0.75))

    def __init__(self, emit, cancel, enabled=True):
        self.emit = emit
        self.cancel = cancel
        self.enabled = enabled
        self.next_checkpoint = 0

    def __call__(self, text, current, total):
        value = min(100.0, max(0.0, current * 100 / max(total, 1)))
        # 100 is sent after the installer commits. Never cancel or delay there.
        if value >= 100:
            self.emit(text, 100, 100)
            return
        if self.cancel.is_set():
            raise Cancelled("Operation cancelled.")
        if self.enabled:
            while self.next_checkpoint < len(self.CHECKPOINTS):
                checkpoint, low, high = self.CHECKPOINTS[self.next_checkpoint]
                if checkpoint > value:
                    break
                self.next_checkpoint += 1
                self._hold(text, checkpoint, random.uniform(low, high))
        self.emit(text, value, 100)

    def _hold(self, text, value, duration):
        deadline = time.monotonic() + duration
        frame = 0
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            self.emit(text.rstrip(". …") + "." * (1 + frame % 3), value, 100)
            frame += 1
            if self.cancel.wait(min(0.12, remaining)):
                raise Cancelled("Operation cancelled.")


def smooth_step(displayed, target):
    """Ease toward actual progress, without running ahead of completed work."""
    if target <= displayed:
        return displayed
    delta = target - displayed
    return target if delta <= 0.08 else min(target, displayed + max(0.10, delta * 0.14))
