@echo off
setlocal
cd /d "%~dp0"
echo Aura Injector 1.3 - Build Windows EXE
echo Internet access is needed to download PyInstaller on the first build.
echo The build uses a separate virtual environment.
py -3 -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    set "AURA_PY=py -3"
    goto build
)
python -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    set "AURA_PY=python"
    goto build
)
echo Python 3.10+ or tkinter is missing. See README.txt.
pause
exit /b 1
:build
%AURA_PY% -m venv ".aura-build-venv"
if errorlevel 1 goto failed
".aura-build-venv\Scripts\python.exe" -m pip install "pyinstaller>=6,<7"
if errorlevel 1 goto failed
".aura-build-venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name Aura_Injector_1.3 --distpath dist --workpath .aura-build --specpath .aura-build aura_injector.py
if errorlevel 1 goto failed
copy /y "dist\Aura_Injector_1.3.exe" "Aura_Injector_1.3.exe" >nul
if errorlevel 1 goto failed
echo.
echo Done: Aura_Injector_1.3.exe
echo The standalone EXE can be shared. Python is not needed on the destination PC.
pause
exit /b 0
:failed
echo.
echo Build failed. The error message is shown above.
pause
exit /b 1
