@echo off
setlocal
cd /d "%~dp0"
if exist "Aura_Injector_1.3.exe" (
    start "" "%~dp0Aura_Injector_1.3.exe"
    exit /b 0
)
py -3 -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0aura_injector.py"
    if errorlevel 1 pause
    exit /b
)
python -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    python "%~dp0aura_injector.py"
    if errorlevel 1 pause
    exit /b
)
echo Python 3.10 or newer with tkinter is required.
echo Download: https://www.python.org/downloads/windows/
echo In the installer, enable: Add Python to PATH, and Tcl/Tk and IDLE.
echo Then run this launcher again.
pause
exit /b 1
